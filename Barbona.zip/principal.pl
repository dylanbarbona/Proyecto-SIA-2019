:- include('minaExample.pl').

/*---------------------------------------------------------------------------------*/
/*------------------------ESTADOS DEL MINERO---------------------------------------*/
/*---------------------------------------------------------------------------------*/
% grafo(+EstadoActual, -EstadoNuevo, -Operacion, -Costo).

/* Operacion para caminar. */
grafo(EstadoActual, EstadoNuevo, caminar, Costo):- 
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], Dir, ListadoPosesiones, ColocacionCargaPendiente),
    
    % De acuerdo a la direcci�n del minero, se obtiene la posici�n [Xn, Yn]
    ((Dir == n, Xn is X-1, Yn is Y); (Dir == s, Xn is X+1, Yn is Y);       
    (Dir == o, Xn is X, Yn is Y-1); (Dir == e, Xn is X, Yn is Y+1)),  
    
    %Se obtiene el tipo de suelo, y partir de eso, su costo asociado
    celda([Xn,Yn], TipoSuelo),
    ((TipoSuelo = firme, Costo is 2); (TipoSuelo = resbaladizo, Costo is 3)), 
    
    % No debe haber obstaculos en la nueva posicion. Solo rejas que pueden abrirse (con su correspondiente llave)
    not(estaEn([p, _Pilar, _AlturaPilar], [Xn, Yn])),                         
    not(estaEn([v, _Valla, _AlturaValla], [Xn, Yn])),                         
    (
        (not(estaEn([r, _Reja],[Xn,Yn])));                                    
        (estaEn([r, Reja],[Xn,Yn]), member([l,Llave], ListadoPosesiones), abreReja([l,Llave],[r,Reja])) 
    ),
    
    % Se obtiene el estado siguiente del minero, con la nueva posici�n
    EstadoNuevo = estado([Xn,Yn], Dir, ListadoPosesiones, ColocacionCargaPendiente). 


/* Operacion para rotar(Dir). */
grafo(EstadoActual, EstadoNuevo, rotar(Dir), Costo):-
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], DirVieja, ListadoPosesiones, ColocacionCargaPendiente),
    
    % La direcci�n solo puede ser [n, s, e, o]
    member(Dir, [n, s, e, o]),
    
    % La direccion nueva debe diferir de la actual
    (DirVieja \= Dir),           
    
    % Distintas configuraciones de rotaci�n, y el costo asociado a cada uno
    (                                                                              
     (DirVieja == n, Dir == s, Costo = 2);
     (DirVieja == n, Dir == e, Costo = 1);
     (DirVieja == n, Dir == o, Costo = 1);
     (DirVieja == s, Dir == n, Costo = 2);
     (DirVieja == s, Dir == e, Costo = 1);
     (DirVieja == s, Dir == o, Costo = 1);
     (DirVieja == e, Dir == o, Costo = 2);
     (DirVieja == e, Dir == n, Costo = 1);
     (DirVieja == e, Dir == s, Costo = 1);
     (DirVieja == o, Dir == e, Costo = 2);
     (DirVieja == o, Dir == n, Costo = 1);
     (DirVieja == o, Dir == s, Costo = 1)
    ),
    
    % Se obtiene el estado siguiente del minero, con la nueva direcci�n
    EstadoNuevo = estado([X,Y], Dir, ListadoPosesiones, ColocacionCargaPendiente).      

/* Operacion para saltar(Dir) */
grafo(EstadoActual, EstadoNuevo, saltar_valla(Valla), Costo):-
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], Dir, ListadoPosesiones, ColocacionCargaPendiente),
    
    % se obtiene la valla, que debe estar en la posici�n adyacente a la actual
    Valla = [v, _NombreV, AlturaV],                                                
    celda([XNew,YNew], _TipoSuelo),
    estaEn(Valla, [XNew, YNew]),
    
    %La altura es menor a 4, entonces puede saltarla
    AlturaV =< 4,
    
    %No es un pilar ni una reja
    not(estaEn([p,_,_],[XNew,YNew])),
    not(estaEn([r,_],[XNew,YNew])),                                                
    
    % Se crea un estado intermedio (que no forma parte del plan), solo para caer en la celda siguiente a la de la valla
    EstadoIntermedio1 = estado([XNew,YNew], Dir, ListadoPosesiones, ColocacionCargaPendiente),   
    grafo(EstadoIntermedio1, EstadoIntermedio2, caminar, CostoSalto),
    EstadoIntermedio2 = estado([XSalto,YSalto], Dir, ListadoPosesiones, ColocacionCargaPendiente),
    
    % El costo asociado al salto es el costo la celda en que cay�, mas uno.
    Costo is CostoSalto+1,
    
    % La direcci�n determina la celda que va a saltar
    ((Dir == n, XNew is X-1, YNew is Y); (Dir == s, XNew is X+1, YNew is Y);       
    (Dir == o, XNew is X, YNew is Y-1); (Dir == e, XNew is X, YNew is Y+1)),
    
    % Se obtiene el estado siguiente del minero, con la celda adyacente a la valla que salt�
    EstadoNuevo = estado([XSalto,YSalto], Dir, ListadoPosesiones, ColocacionCargaPendiente).


/* Operacion para juntar_llave(Llave) */
grafo(EstadoActual, EstadoNuevo, juntar_llave(Llave), Costo):-
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], Dir, ListadoPosesiones, ColocacionCargaPendiente),
    
    % La llave tiene que estar en la posici�n actual del minero
    Llave = [l, _NombreL],
    estaEn(Llave, [X,Y]),
    
    % El costo asociado a juntar la llave es 1
    Costo = 1,
    
    % El minero no debe tener la llave entre sus posesiones
    not(member(Llave, ListadoPosesiones)),
    
    % Se obtiene el estado siguiente del minero, con la nueva llave
    EstadoNuevo = estado([X,Y], Dir, [Llave | ListadoPosesiones], ColocacionCargaPendiente).

/* Operacion para juntar_carga(Carga) */
grafo(EstadoActual, EstadoNuevo, juntar_carga(Carga), Costo):-
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], Dir, ListadoPosesiones, _),
    
    % La carga tiene que estar en la posici�n actual del minero
    Carga = [c, _NombreC],
    estaEn(Carga, [X,Y]),   
    
    % El minero no debe tener la carga entre sus posesiones
    not(member(Carga, ListadoPosesiones)),
    
    % El costo asociado a juntar la carga es 3
    Costo = 3,                              
    
    % Se obtiene el estado siguiente del minero, con la nueva carga, seteando en 'si' el indicador de colocar la carga
    EstadoNuevo = estado([X,Y], Dir, [Carga | ListadoPosesiones], 'si').

/* Operacion para dejar_carga(Carga) */
grafo(EstadoActual, EstadoNuevo, dejar_carga(Carga), Costo):-
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], Dir, ListadoPosesiones, 'si'),
    
    % El minero debe estar en la ubicaci�n donde debe dejar la carga
    ubicacionCarga([X,Y]),
    
    % La carga debe estar entre las posesiones del minero
    member(Carga, ListadoPosesiones),
    
    %El costo asociado a dejar la carga es 1
    Costo = 1,
    
    % Se obtiene el estado siguiente del minero, seteando en 'no' el indicador de colocar carga
    EstadoNuevo = estado([X,Y], Dir, ListadoPosesiones, 'no').

/* Operacion para juntar_detonador(Detonador) */ 
grafo(EstadoActual, EstadoNuevo, juntar_detonador(Detonador), Costo):-
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], Dir, ListadoPosesiones, _),
    
    % El detonador tiene que estar en la posici�n actual del minero
    Detonador = [d, _NombreD, no],
    estaEn(Detonador, [X,Y]),
    
    % El minero no debe tener el detonador entre sus posesiones
    not(member(Detonador, ListadoPosesiones)),
    
    % El costo asociado a juntar el detonador es 2
    Costo = 2,
    
    % Se obtiene el estado siguiente del minero, con el nuevo detonador
    EstadoNuevo = estado([X,Y], Dir, [Detonador | ListadoPosesiones], _).

/* Operacion para detonar(Detonador) */
grafo(EstadoActual, EstadoNuevo, detonar(Detonador), Costo):-
    % Se obtiene el estado actual del minero
    EstadoActual = estado([X,Y], Dir, ListadoPosesiones, 'no'),
    
    % El minero debe tener el detonador entre sus posesiones, sin detonar
    Detonador = [d, NombreD, 'no'],
    member([c,_], ListadoPosesiones),
    member(Detonador, ListadoPosesiones),
    not(member([d, NombreD, 'si'], ListadoPosesiones)),
    sitioDetonacion([X,Y]),
    
    % El costo asociado a detonar es 1
    Costo = 1,
    
    % Se obtiene el estado siguiente del minero, seteando en 'si' el detonador
    EstadoNuevo = estado([X,Y], Dir, [[d, NombreD, 'si'] | ListadoPosesiones], 'no').

/*---------------------------------------------------------------------------------*/
/*-------------------------------METAS DEL MINERO----------------------------------*/
/*---------------------------------------------------------------------------------*/
% h(+Estado, +Metas, -Distancia).
% obtenerMetas(+Estado, -ListaMetas).
% meta(+Estado, -[X,Y]).


/* Tiene que encontrar la carga */
meta(Estado, [X,Y]):-
   Estado = estado([_,_], _, ListadoPosesiones, _),
   not(member([c, Carga], ListadoPosesiones)),
   estaEn([c, Carga], [X,Y]).

/* Ya coloco la carga y debe buscar el detonador */
meta(Estado, [X,Y]):-
   Estado = estado([_,_], _, ListadoPosesiones, _),
   not(member([d, Detonador, no], ListadoPosesiones)),
   estaEn([d, Detonador, no], [X,Y]).

/* Ya encontro la carga y tiene que ubicarla */
meta(Estado, [X,Y]):-
   Estado = estado([_,_], _, ListadoPosesiones, 'si'),
   member([c, _], ListadoPosesiones),
   ubicacionCarga([X,Y]).

/* Ya encontro el detonador y debe ir al sitio de detonacion */
meta(Estado, [X,Y]):-
   Estado = estado([_,_], _, ListadoPosesiones, 'no'),
   member([c, _], ListadoPosesiones),
   member([d, _, no], ListadoPosesiones),
   not(member([d, _, si], ListadoPosesiones)),
   sitioDetonacion([X,Y]).

esMeta(Nodo, Metas):-
    Nodo = nodo(_, [_, Estado], _),
    Estado = estado([X,Y], _, _, _),
    member([X,Y], Metas),
    not(meta(Estado, [X,Y])).

/* Esta heuristica retorna la distancia de la meta mas cercana al minero */
h(Estado, Metas, Distancia):-
    metasOrdenadas(Estado, Metas, [[Xm,Ym] | _]),
    Estado = estado([X,Y], _, _, _),
    Distancia is (abs(Xm - X) + abs(Ym - Y)).

/* Obtiene las metas ordenadas de acuerdo a la distancia con el minero */
metasOrdenadas(Estado, ListaMetas, MetasOrdenadas):-
   distanciasMeta(Estado, ListaMetas, ListaResultados),
   keysort(ListaResultados, Pares),
   separar_pares_valores(Pares, MetasOrdenadas), !.
    
/* Obtiene las distancias de cada meta con el minero */
distanciasMeta(_Estado, [], []).
distanciasMeta(Estado, [[X,Y] | ListaMetas], [Resultado-[X,Y] | ListaResultados]):-
   Estado = estado([XInicial, YInicial], _, _, _),
   Resultado is (abs(XInicial - X) + abs(YInicial-Y)),
   distanciasMeta(Estado, ListaMetas, ListaResultados).

/* Sirve para separar las claves-valores que se obtienen en el keysort */
separar_pares_valores([], []).
separar_pares_valores([_-V|T0], [V|T]) :-
   separar_pares_valores(T0, T).
    
/* Obtiene las metas, las cuales el minero puede alcanzar desde su estado actual */
obtenerMetas(Estado, ListaMetas):-
   	findall([X,Y], meta(Estado, [X,Y]), ListaMetas).

/*---------------------------------------------------------------------------------*/
/*-------------------------------ALGORITMO A*--------------------------------------*/
/*---------------------------------------------------------------------------------*/
% buscar_plan([[+X,+Y], +Dir, +Posesiones, +CargaPendiente], -Plan, -Destino, -Costo)

/* A partir de un estado inicial, obtiene un plan, el destino y el costo total asociado */
buscar_plan([[X,Y], Dir, ListaPosesiones, ColocacionCargaPendiente], Plan, Destino, Costo):-
    % Crea el estado inicial
    EstadoInicial = estado([X,Y], Dir, ListaPosesiones, ColocacionCargaPendiente),
    
    % Comienza el algoritmo a*, con el nodo inicial y obtiene el nodo final, con su estado, destino y operadores necesarios para llegar
	a_estrella([nodo(0, [inicial, EstadoInicial], [])], [], nodo(Costo, [OperacionFinal, EFinal], Lista)),
    EFinal = estado([XFinal,YFinal],_,_,_),
    Destino = [XFinal,YFinal],
    
    % La lista de operadores est� al rev�s, por lo que es necesario darlo vuelta
   	obtenerOperadores([[OperacionFinal, EFinal] | Lista], PlanRev),
    reverse(PlanRev, Plan), !.

% Obtiene los operadores a partir del nodo final
obtenerOperadores([[inicial, _EFinal] | []], []).
obtenerOperadores([[Operacion, _EstListaado] | Lista], [Operacion | RestoOperadores]):-
    obtenerOperadores(Lista, RestoOperadores).

% Comienza un ciclo del algoritmo a* por cada meta que tenga que cumplir
a_estrella([nodo(Costo, [Op, Estado], Nodos)], Visitados, UltimoNodo):-
    NodoInicial = nodo(Costo, [Op, Estado], Nodos),
    obtenerMetas(Estado, Metas),
    buscarEn([NodoInicial], Metas, Visitados, NodoFinal),
    a_estrella([NodoFinal], Visitados, UltimoNodo).

% Si no tiene mas metas, entonces termina
a_estrella([nodo(Costo, [Operacion, Estado], Nodos)], _, nodo(Costo, [Operacion, Estado], Nodos)):-
    obtenerMetas(Estado, []).

buscarEn(Frontera, Metas, _Vis, NodoF):-
    seleccionar(Frontera, Metas, NodoF),
    esMeta(NodoF, Metas).

buscarEn(Frontera, Metas, Visitados, MejorCamino):- 
    seleccionar(Frontera, Metas, Nodo),
    Nodo = nodo(_Costo, [_Operacion, Estado], _Camino),
	delete(Frontera, Nodo, FronteraSinNodo),
	vecinos(Nodo, Frontera, Visitados, Vecinos),
	agregar(Vecinos, FronteraSinNodo, NuevaFrontera),
	buscarEn(NuevaFrontera, Metas, [Estado | Visitados], MejorCamino).

% Sirve para crear la nueva frontera, eliminando aquellos nodos con mayor costo, dejando solo el de coste minimo
agregar([], CaminosViejos, CaminosViejos).

agregar([nodo(CostoNuevo, [Operacion, Estado], RestoNuevo) | RestoCaminosNuevos], CaminosViejos, [nodo(CostoNuevo, [Operacion, Estado], RestoNuevo) | RestoCaminosFiltrados]):-
	member(nodo(CostoViejo, [OperacionVieja, Estado], RestoViejo), CaminosViejos),
	CostoNuevo < CostoViejo,
	delete(nodo(CostoViejo, [OperacionVieja, Estado], RestoViejo), CaminosViejos, CaminosViejosSinPeor),
	agregar(RestoCaminosNuevos, CaminosViejosSinPeor, RestoCaminosFiltrados).

agregar([nodo(_CostoNuevo, [_Operacion, Estado], _RestoNuevo) | RestoCaminosNuevos], CaminosViejos, CaminosFiltrados):-
	member(nodo(_CostoViejo, [_OperacionVieja, Estado], _RestoViejo), CaminosViejos),
	agregar(RestoCaminosNuevos, CaminosViejos, CaminosFiltrados).

agregar([CaminoNuevo | RestoCaminosNuevos], CaminosViejos, [CaminoNuevo | RestoCaminosFiltrados]):-
	agregar(RestoCaminosNuevos, CaminosViejos, RestoCaminosFiltrados).

% Sirve para buscar los vecinos del nodo, que no hayan sido visitados
vecinos(Nodo, Frontera, Visitados, Vecinos):-
	Nodo = nodo(Costo, [Operacion, Estado], Camino),
    % Busca todos los estados posibles a partir del actual, que no pertenezcan a los visitados ni a la frontera
    findall(
    	nodo(Costo, [OperacionSiguiente, EstadoSiguiente], [[Operacion, Estado] | Camino]),
        (grafo(Estado, EstadoSiguiente, OperacionSiguiente, _),
         not(member(EstadoSiguiente, Visitados)),
         not(member(nodo(_, [_, EstadoSiguiente], _), Frontera))
        ),
        Lista),
    % Cambia los costos de la lista resultante
    cambiar_costos(Lista, Vecinos).

% Obtiene los nuevos costos
cambiar_costos([],[]):- !.
cambiar_costos([nodo(CostoTotal, [OpSiguiente, EstadoSiguiente], [[OpActual, EstadoActual] | Camino]) | Y],
               [nodo(NuevoCostoTotal, [OpSiguiente, EstadoSiguiente], [[OpActual, EstadoActual] | Camino]) | Z]):-
	grafo(EstadoActual, EstadoSiguiente, OpSiguiente, CostoOperacion),
	NuevoCostoTotal is CostoTotal + CostoOperacion,
	cambiar_costos(Y,Z).

% Selecciona el nodo con mejor f de la frontera de acuerdo a la lista de metas
seleccionar([X], _Metas, X):- !.
seleccionar([nodo(C1, [Operacion, E1], Y), nodo(C2, [_, E2], _) | Z], Metas, MejorF):-
    % Calcula la función h
	h(E1, Metas, H1),
	h(E2, Metas, H2),
    % Evalua cual tiene el menor costo, de acuerdo a la funcion f(t) = h(t) + g(t)
	H1 + C1 =< H2 + C2,	% F1 <= F2
    % Sigue buscando
	seleccionar([nodo(C1, [Operacion, E1], Y) | Z], Metas, MejorF).

% Idem al predicado anterior, solo que este evalua si f1 > f2
seleccionar([nodo(C1, [_, E1], _), nodo(C2, [Operacion, E2], Y) | Z], Metas, MejorF):-
	h(E1, Metas, H1),
	h(E2, Metas, H2),
	H1 + C1 > H2 + C2,	% F1 > F2
	seleccionar([nodo(C2, [Operacion, E2], Y) | Z], Metas, MejorF).